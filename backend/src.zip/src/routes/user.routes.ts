import { Router } from "express";

import prisma from "../lib/prisma";

const router = Router();

/*
  GET USER
*/
router.get(
  "/:clerkId",
  async (req, res) => {
    try {
      const { clerkId } =
        req.params;

      const user =
        await prisma.user.findUnique(
          {
            where: {
              clerkId,
            },
          }
        );

      res.json(user);
    } catch (error) {
      console.error(error);

      res.status(500).json({
        error:
          "Failed to fetch user",
      });
    }
  }
);

export default router;